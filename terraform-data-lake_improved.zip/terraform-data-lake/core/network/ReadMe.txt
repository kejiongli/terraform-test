# Default inet route
#
# Fix for this error encountered during health checks - [ 1020.660187] configure.sh[972]: == Failed to download https://storage.googleapis.com/gke-release/npd-custom-plugins/v1.0.4/npd-custom-plugins-v1.0.4.tar.gz. Retrying. == 
# Counter-Intuitive given this is supposed to be a PRIVATE cluster
#